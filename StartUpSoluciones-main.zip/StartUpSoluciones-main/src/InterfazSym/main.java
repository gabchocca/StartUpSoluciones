package InterfazSym;
import com.formdev.flatlaf.FlatLaf;
import javax.swing.UIManager;
import com.formdev.flatlaf.intellijthemes.FlatGradiantoDeepOceanIJTheme;
import java.awt.Font;

public class main {

    public static void main(String[] args) {
       
        try {
            // Activar el tema FlatLaf Dark
            UIManager.setLookAndFeel(new FlatGradiantoDeepOceanIJTheme());
            UIManager.put("defaultFont", new Font("Bahnschrift", Font.PLAIN, 14));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        java.awt.EventQueue.invokeLater(() -> {
            new InicioPrinci().setVisible(true);
        });
    };
    
    
}
